document.querySelectorAll('.story').forEach((story, index) => {
  story.addEventListener('click', () => {
    alert(`You clicked on Story ${index + 1}`);
  });
});
